//
//  EntitiesHomeDisplaySettings.swift
//  BrainMesh
//
//  PR 02: Display settings for Entities Home.
//  PR 04: Add layout mode (list/grid) for quick in-screen view settings.
//

import Foundation

enum EntitiesHomeLayoutMode: String, Codable, CaseIterable, Identifiable {
    case list
    case grid

    var id: String { rawValue }
}

enum EntitiesHomeListStyle: String, Codable, CaseIterable, Identifiable {
    case plain
    case insetGrouped
    case cards

    var id: String { rawValue }
}

enum EntitiesHomeRowStyle: String, Codable, CaseIterable, Identifiable {
    case titleOnly
    case titleWithSubtitle
    case titleWithBadges

    var id: String { rawValue }
}

enum EntitiesHomeRowDensity: String, Codable, CaseIterable, Identifiable {
    case compact
    case standard
    case comfortable

    var id: String { rawValue }
}

enum EntitiesHomeBadgeStyle: String, Codable, CaseIterable, Identifiable {
    case none
    case smallCounter
    case pills

    var id: String { rawValue }
}

enum EntitiesHomeMetaLine: String, Codable, CaseIterable, Identifiable {
    case none
    case notesPreview
    case counts

    var id: String { rawValue }
}

struct EntitiesHomeDisplaySettings: Codable, Equatable {

    // MARK: - New visual knobs (PRs 04/05 will start using these)

    var layout: EntitiesHomeLayoutMode
    var listStyle: EntitiesHomeListStyle
    var rowStyle: EntitiesHomeRowStyle
    var density: EntitiesHomeRowDensity
    var showSeparators: Bool
    var badgeStyle: EntitiesHomeBadgeStyle
    var metaLine: EntitiesHomeMetaLine
    var showCockpit: Bool

    // MARK: - Existing knobs (currently still sourced from Appearance; included here as foundation)

    var showAttributeCount: Bool
    var showLinkCount: Bool
    var showNotesPreview: Bool
    var preferThumbnailOverIcon: Bool

    // MARK: - Defaults

    static func preset(_ preset: DisplayPreset) -> EntitiesHomeDisplaySettings {
        switch preset {
        case .clean:
            return EntitiesHomeDisplaySettings(
                layout: .list,
                listStyle: .plain,
                rowStyle: .titleOnly,
                density: .standard,
                showSeparators: true,
                badgeStyle: .none,
                metaLine: .none,
                showCockpit: true,
                showAttributeCount: false,
                showLinkCount: false,
                showNotesPreview: false,
                preferThumbnailOverIcon: false
            )
        case .dense:
            return EntitiesHomeDisplaySettings(
                layout: .list,
                listStyle: .plain,
                rowStyle: .titleWithBadges,
                density: .compact,
                showSeparators: false,
                badgeStyle: .smallCounter,
                metaLine: .none,
                showCockpit: false,
                showAttributeCount: true,
                showLinkCount: true,
                showNotesPreview: false,
                preferThumbnailOverIcon: false
            )
        case .visual:
            return EntitiesHomeDisplaySettings(
                layout: .grid,
                listStyle: .cards,
                rowStyle: .titleWithSubtitle,
                density: .comfortable,
                showSeparators: false,
                badgeStyle: .pills,
                metaLine: .notesPreview,
                showCockpit: true,
                showAttributeCount: false,
                showLinkCount: false,
                showNotesPreview: true,
                preferThumbnailOverIcon: true
            )
        case .pro:
            return EntitiesHomeDisplaySettings(
                layout: .list,
                listStyle: .insetGrouped,
                rowStyle: .titleWithSubtitle,
                density: .standard,
                showSeparators: true,
                badgeStyle: .pills,
                metaLine: .counts,
                showCockpit: true,
                showAttributeCount: true,
                showLinkCount: true,
                showNotesPreview: true,
                preferThumbnailOverIcon: true
            )
        }
    }

    static let `default` = EntitiesHomeDisplaySettings.preset(.clean)

    // MARK: - Performance metadata (labeling only; UI comes later)

    enum OptionKey: String, CaseIterable {
        case layout
        case listStyle
        case rowStyle
        case density
        case showSeparators
        case badgeStyle
        case metaLine
        case showCockpit
        case showAttributeCount
        case showLinkCount
        case showNotesPreview
        case preferThumbnailOverIcon
    }

    static let optionMeta: [OptionKey: DisplayOptionMeta] = [
        .layout: DisplayOptionMeta(impact: .none),
        .listStyle: DisplayOptionMeta(impact: .none),
        .rowStyle: DisplayOptionMeta(impact: .none),
        .density: DisplayOptionMeta(impact: .none),
        .showSeparators: DisplayOptionMeta(impact: .none),
        .badgeStyle: DisplayOptionMeta(impact: .none),
        .metaLine: DisplayOptionMeta(impact: .low),
        .showCockpit: DisplayOptionMeta(impact: .medium, note: "Lädt kompakte Home-Hinweise und Quick-Filter für den aktiven Graph."),
        .showAttributeCount: DisplayOptionMeta(impact: .high, note: "Kann zusätzliche Zähl-Queries auslösen."),
        .showLinkCount: DisplayOptionMeta(impact: .medium, note: "Kann zusätzliche Zähl-Queries auslösen."),
        .showNotesPreview: DisplayOptionMeta(impact: .low, note: "Mehr Text kann das Rendering/Scrolling etwas belasten."),
        .preferThumbnailOverIcon: DisplayOptionMeta(impact: .medium, note: "Thumbnails können zusätzliche Loads/Hydration triggern.")
    ]

    // MARK: - Codable (forward compatible)

    private enum CodingKeys: String, CodingKey {
        case layout
        case listStyle
        case rowStyle
        case density
        case showSeparators
        case badgeStyle
        case metaLine
        case showCockpit
        case showAttributeCount
        case showLinkCount
        case showNotesPreview
        case preferThumbnailOverIcon
    }

    init(
        layout: EntitiesHomeLayoutMode,
        listStyle: EntitiesHomeListStyle,
        rowStyle: EntitiesHomeRowStyle,
        density: EntitiesHomeRowDensity,
        showSeparators: Bool,
        badgeStyle: EntitiesHomeBadgeStyle,
        metaLine: EntitiesHomeMetaLine,
        showCockpit: Bool,
        showAttributeCount: Bool,
        showLinkCount: Bool,
        showNotesPreview: Bool,
        preferThumbnailOverIcon: Bool
    ) {
        self.layout = layout
        self.listStyle = listStyle
        self.rowStyle = rowStyle
        self.density = density
        self.showSeparators = showSeparators
        self.badgeStyle = badgeStyle
        self.metaLine = metaLine
        self.showCockpit = showCockpit
        self.showAttributeCount = showAttributeCount
        self.showLinkCount = showLinkCount
        self.showNotesPreview = showNotesPreview
        self.preferThumbnailOverIcon = preferThumbnailOverIcon
    }

    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)

        let fallback = EntitiesHomeDisplaySettings.default

        self.layout = try container.decodeIfPresent(EntitiesHomeLayoutMode.self, forKey: .layout) ?? fallback.layout
        self.listStyle = try container.decodeIfPresent(EntitiesHomeListStyle.self, forKey: .listStyle) ?? fallback.listStyle
        self.rowStyle = try container.decodeIfPresent(EntitiesHomeRowStyle.self, forKey: .rowStyle) ?? fallback.rowStyle
        self.density = try container.decodeIfPresent(EntitiesHomeRowDensity.self, forKey: .density) ?? fallback.density
        self.showSeparators = try container.decodeIfPresent(Bool.self, forKey: .showSeparators) ?? fallback.showSeparators
        self.badgeStyle = try container.decodeIfPresent(EntitiesHomeBadgeStyle.self, forKey: .badgeStyle) ?? fallback.badgeStyle
        self.metaLine = try container.decodeIfPresent(EntitiesHomeMetaLine.self, forKey: .metaLine) ?? fallback.metaLine
        self.showCockpit = try container.decodeIfPresent(Bool.self, forKey: .showCockpit) ?? fallback.showCockpit

        self.showAttributeCount = try container.decodeIfPresent(Bool.self, forKey: .showAttributeCount) ?? fallback.showAttributeCount
        self.showLinkCount = try container.decodeIfPresent(Bool.self, forKey: .showLinkCount) ?? fallback.showLinkCount
        self.showNotesPreview = try container.decodeIfPresent(Bool.self, forKey: .showNotesPreview) ?? fallback.showNotesPreview
        self.preferThumbnailOverIcon = try container.decodeIfPresent(Bool.self, forKey: .preferThumbnailOverIcon) ?? fallback.preferThumbnailOverIcon
    }
}
