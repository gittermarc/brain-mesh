//
//  NodePickerLoader.swift
//  BrainMesh
//
//  P0.1: Load NodePicker / NodeMultiPicker data off the UI thread.
//  Goal: Avoid blocking the main thread with SwiftData fetches when opening pickers
//  or typing search terms (10k+ nodes should still feel instant).
//

import Foundation
import SwiftData
import os

/// Value-only row snapshot for pickers.
///
/// Important: Do NOT pass SwiftData `@Model` instances across concurrency boundaries.
/// The UI navigates by `id` and resolves the model from its main `ModelContext`.
struct NodePickerRowDTO: Identifiable, Hashable, Sendable {
    /// `NodeKind.rawValue` (we keep the DTO fully Sendable without relying on `NodeKind: Sendable`).
    let kindRaw: Int
    let id: UUID
    let label: String
    let iconSymbolName: String?
}

actor NodePickerLoader {

    static let shared = NodePickerLoader()

    private var container: AnyModelContainer? = nil
    private let log = Logger(subsystem: "BrainMesh", category: "NodePickerLoader")

    func configure(container: AnyModelContainer) {
        self.container = container
        #if DEBUG
        log.debug("✅ configured")
        #endif
    }

    func loadEntities(graphID: UUID?, foldedSearch: String, limit: Int) async throws -> [NodePickerRowDTO] {
        try await load(kindRaw: NodeKind.entity.rawValue, graphID: graphID, foldedSearch: foldedSearch, limit: limit)
    }

    func loadAttributes(graphID: UUID?, foldedSearch: String, limit: Int) async throws -> [NodePickerRowDTO] {
        try await load(kindRaw: NodeKind.attribute.rawValue, graphID: graphID, foldedSearch: foldedSearch, limit: limit)
    }

    func loadExistingRows(graphID: UUID?, kind: NodeKind, ids: [UUID]) async throws -> [NodePickerRowDTO] {
        try await loadExistingRows(kindRaw: kind.rawValue, graphID: graphID, ids: ids)
    }

    private func loadExistingRows(kindRaw: Int, graphID: UUID?, ids: [UUID]) async throws -> [NodePickerRowDTO] {
        let uniqueIDs = NodePickerLoader.uniqueIDsPreservingOrder(ids)
        guard uniqueIDs.isEmpty == false else { return [] }

        let configuredContainer = self.container
        guard let configuredContainer else {
            throw NSError(
                domain: "BrainMesh.NodePickerLoader",
                code: 1,
                userInfo: [NSLocalizedDescriptionKey: "NodePickerLoader not configured"]
            )
        }

        let k = kindRaw
        let gid = graphID

        return try await Task.detached(priority: .utility) { [configuredContainer, k, gid, uniqueIDs] in
            let context = ModelContext(configuredContainer.container)
            context.autosaveEnabled = false

            if k == NodeKind.entity.rawValue {
                return try NodePickerLoader.fetchEntityRows(
                    context: context,
                    graphID: gid,
                    ids: uniqueIDs
                )
            } else {
                return try NodePickerLoader.fetchAttributeRows(
                    context: context,
                    graphID: gid,
                    ids: uniqueIDs
                )
            }
        }.value
    }

    private func load(kindRaw: Int, graphID: UUID?, foldedSearch: String, limit: Int) async throws -> [NodePickerRowDTO] {
        let configuredContainer = self.container
        guard let configuredContainer else {
            throw NSError(
                domain: "BrainMesh.NodePickerLoader",
                code: 1,
                userInfo: [NSLocalizedDescriptionKey: "NodePickerLoader not configured"]
            )
        }

        let k = kindRaw
        let gid = graphID
        let term = foldedSearch
        let lim = limit

        return try await Task.detached(priority: .utility) { [configuredContainer, k, gid, term, lim] in
            let context = ModelContext(configuredContainer.container)
            context.autosaveEnabled = false

            if k == NodeKind.entity.rawValue {
                return try NodePickerLoader.fetchEntityRows(
                    context: context,
                    graphID: gid,
                    foldedSearch: term,
                    limit: lim
                )
            } else {
                return try NodePickerLoader.fetchAttributeRows(
                    context: context,
                    graphID: gid,
                    foldedSearch: term,
                    limit: lim
                )
            }
        }.value
    }

    private static func fetchEntityRows(
        context: ModelContext,
        graphID: UUID?,
        foldedSearch: String,
        limit: Int
    ) throws -> [NodePickerRowDTO] {
        let gid = graphID

        let fd: FetchDescriptor<MetaEntity>
        if foldedSearch.isEmpty {
            if let gid {
                fd = FetchDescriptor(
                    predicate: #Predicate<MetaEntity> { e in
                        e.graphID == gid
                    },
                    sortBy: [SortDescriptor(\MetaEntity.name)]
                )
            } else {
                fd = FetchDescriptor(sortBy: [SortDescriptor(\MetaEntity.name)])
            }
        } else {
            let term = foldedSearch
            if let gid {
                fd = FetchDescriptor(
                    predicate: #Predicate<MetaEntity> { e in
                        e.graphID == gid && e.nameFolded.contains(term)
                    },
                    sortBy: [SortDescriptor(\MetaEntity.name)]
                )
            } else {
                fd = FetchDescriptor(
                    predicate: #Predicate<MetaEntity> { e in
                        e.nameFolded.contains(term)
                    },
                    sortBy: [SortDescriptor(\MetaEntity.name)]
                )
            }
        }

        var descriptor = fd
        descriptor.fetchLimit = limit
        let entities = try context.fetch(descriptor)
        return entities.map { e in
            NodePickerRowDTO(
                kindRaw: NodeKind.entity.rawValue,
                id: e.id,
                label: e.name,
                iconSymbolName: e.iconSymbolName
            )
        }
    }

    private static func fetchEntityRows(
        context: ModelContext,
        graphID: UUID?,
        ids: [UUID]
    ) throws -> [NodePickerRowDTO] {
        guard ids.isEmpty == false else { return [] }
        let entityIDs = ids
        let fd: FetchDescriptor<MetaEntity>
        if let graphID {
            fd = FetchDescriptor<MetaEntity>(predicate: #Predicate<MetaEntity> { entity in
                entityIDs.contains(entity.id) && entity.graphID == graphID
            })
        } else {
            fd = FetchDescriptor<MetaEntity>(predicate: #Predicate<MetaEntity> { entity in
                entityIDs.contains(entity.id)
            })
        }

        let fetched = try context.fetch(fd)
        let rowsByID = Dictionary(uniqueKeysWithValues: fetched.map { entity in
            (
                entity.id,
                NodePickerRowDTO(
                    kindRaw: NodeKind.entity.rawValue,
                    id: entity.id,
                    label: entity.name,
                    iconSymbolName: entity.iconSymbolName
                )
            )
        })

        return ids.compactMap { rowsByID[$0] }
    }

    private static func fetchAttributeRows(
        context: ModelContext,
        graphID: UUID?,
        foldedSearch: String,
        limit: Int
    ) throws -> [NodePickerRowDTO] {
        let gid = graphID

        let fd: FetchDescriptor<MetaAttribute>
        if foldedSearch.isEmpty {
            if let gid {
                fd = FetchDescriptor(
                    predicate: #Predicate<MetaAttribute> { a in
                        a.graphID == gid
                    },
                    sortBy: [SortDescriptor(\MetaAttribute.name)]
                )
            } else {
                fd = FetchDescriptor(sortBy: [SortDescriptor(\MetaAttribute.name)])
            }
        } else {
            let term = foldedSearch
            if let gid {
                fd = FetchDescriptor(
                    predicate: #Predicate<MetaAttribute> { a in
                        a.graphID == gid && a.searchLabelFolded.contains(term)
                    },
                    sortBy: [SortDescriptor(\MetaAttribute.name)]
                )
            } else {
                fd = FetchDescriptor(
                    predicate: #Predicate<MetaAttribute> { a in
                        a.searchLabelFolded.contains(term)
                    },
                    sortBy: [SortDescriptor(\MetaAttribute.name)]
                )
            }
        }

        var descriptor = fd
        descriptor.fetchLimit = limit
        let attributes = try context.fetch(descriptor)
        return attributes.map { a in
            NodePickerRowDTO(
                kindRaw: NodeKind.attribute.rawValue,
                id: a.id,
                label: a.displayName,
                iconSymbolName: a.iconSymbolName
            )
        }
    }

    private static func fetchAttributeRows(
        context: ModelContext,
        graphID: UUID?,
        ids: [UUID]
    ) throws -> [NodePickerRowDTO] {
        guard ids.isEmpty == false else { return [] }
        let attributeIDs = ids
        let fd: FetchDescriptor<MetaAttribute>
        if let graphID {
            fd = FetchDescriptor<MetaAttribute>(predicate: #Predicate<MetaAttribute> { attribute in
                attributeIDs.contains(attribute.id) && attribute.graphID == graphID
            })
        } else {
            fd = FetchDescriptor<MetaAttribute>(predicate: #Predicate<MetaAttribute> { attribute in
                attributeIDs.contains(attribute.id)
            })
        }

        let fetched = try context.fetch(fd)
        let rowsByID = Dictionary(uniqueKeysWithValues: fetched.map { attribute in
            (
                attribute.id,
                NodePickerRowDTO(
                    kindRaw: NodeKind.attribute.rawValue,
                    id: attribute.id,
                    label: attribute.displayName,
                    iconSymbolName: attribute.iconSymbolName
                )
            )
        })

        return ids.compactMap { rowsByID[$0] }
    }

    private static func uniqueIDsPreservingOrder(_ ids: [UUID]) -> [UUID] {
        var seen: Set<UUID> = []
        var output: [UUID] = []
        output.reserveCapacity(ids.count)

        for id in ids where seen.insert(id).inserted {
            output.append(id)
        }

        return output
    }
}
