//
//  EntityDetailView+Highlights.swift
//  BrainMesh
//
//  P0.3 Split: Highlights row wrapper (shared tiles live in NodeDetailShared)
//

import SwiftUI

struct EntityDetailHighlightsRow: View {
    @EnvironmentObject private var tabRouter: RootTabRouter
    @EnvironmentObject private var graphJump: GraphJumpCoordinator
    @AppStorage(BMAppStorageKeys.activeGraphID) private var activeGraphIDString: String = ""

    private var activeGraphID: UUID? { UUID(uuidString: activeGraphIDString) }

    let graphID: UUID?
    let nodeKey: NodeKey

    let notes: String
    let outgoingLinks: [MetaLink]
    let incomingLinks: [MetaLink]

    /// Media preview + counts (P0.2).
    let galleryThumbs: [MetaAttachment]
    let galleryCount: Int
    let attachmentCount: Int

    let onEditNotes: () -> Void
    let onJumpToMedia: () -> Void
    let onJumpToConnections: () -> Void

    var body: some View {
        let noteSnippet = notes.trimmingCharacters(in: .whitespacesAndNewlines)
        let hasNote = !noteSnippet.isEmpty
        let topLinks = NodeTopLinks.compute(outgoing: outgoingLinks, incoming: incomingLinks, max: 2)
        let hasMedia = (galleryCount + attachmentCount) > 0

        return NodeHighlightsRow {
            NodeHighlightTile(
                title: "Notiz",
                systemImage: "note.text",
                subtitle: hasNote ? NodeTopLinks.previewText(MarkdownCommands.plainText(from: noteSnippet), maxChars: 80) : "Noch keine Notiz",
                subtitleMarkdown: hasNote ? noteSnippet : nil,
                footer: hasNote ? "Tippen zum Bearbeiten" : "Tippen zum Schreiben",
                onTap: { onEditNotes() }
            )

            NodeHighlightTile(
                title: "Medien",
                systemImage: "photo.on.rectangle",
                subtitle: "\(galleryCount) Fotos · \(attachmentCount) Anhänge",
                footer: hasMedia ? "Tippen für Alle" : "Tippen zum Hinzufügen",
                accessory: { NodeMiniThumbStrip(attachments: Array(galleryThumbs.prefix(3))) },
                onTap: { onJumpToMedia() }
            )

            NodeHighlightTile(
                title: "Im Graph",
                systemImage: "circle.grid.cross",
                subtitle: "Node markieren · Verbindungen zeigen",
                footer: "Tippen zum Öffnen",
                onTap: { openInGraph() }
            )

            NodeHighlightTile(
                title: "Top Links",
                systemImage: "link",
                subtitle: topLinks.isEmpty ? "Keine Links" : topLinks.map { $0.label }.joined(separator: " · "),
                footer: "Tippen für Alle",
                onTap: { onJumpToConnections() }
            )
        }
    }

    private func openInGraph() {
        let gid = graphID ?? activeGraphID

        Task { @MainActor in
            if let gid {
                if activeGraphIDString != gid.uuidString {
                    activeGraphIDString = gid.uuidString
                }
                graphJump.requestJump(to: nodeKey, in: gid, centerOnArrival: true)
            }
            tabRouter.openGraph(animated: true)
        }
    }
}
