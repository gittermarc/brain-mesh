//
//  NodeDetailShared+Highlights.swift
//  BrainMesh
//
//  Shared highlight components for Entity/Attribute detail screens.
//

import SwiftUI
import Foundation
import UIKit

struct NodeHighlightsRow<Content: View>: View {
    @ViewBuilder var content: () -> Content

    var body: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 12) {
                content()
            }
            .padding(.horizontal, 2)
        }
        .scrollClipDisabled()
    }
}

struct NodeHighlightTile<Accessory: View>: View {
    let title: String
    let systemImage: String
    let subtitle: String
    let subtitleMarkdown: String?
    let footer: String
    var accessory: (() -> Accessory)? = nil
    let onTap: () -> Void

    init(
        title: String,
        systemImage: String,
        subtitle: String,
        subtitleMarkdown: String? = nil,
        footer: String,
        accessory: (() -> Accessory)? = nil,
        onTap: @escaping () -> Void
    ) {
        self.title = title
        self.systemImage = systemImage
        self.subtitle = subtitle
        self.subtitleMarkdown = subtitleMarkdown
        self.footer = footer
        self.accessory = accessory
        self.onTap = onTap
    }

    var body: some View {
        Button(action: onTap) {
            VStack(alignment: .leading, spacing: 10) {
                HStack(spacing: 8) {
                    Image(systemName: systemImage)
                        .font(.system(size: 14, weight: .semibold))
                        .foregroundStyle(.tint)
                    Text(title)
                        .font(.caption.weight(.semibold))
                        .foregroundStyle(.secondary)
                    Spacer(minLength: 0)
                }

                if let subtitleMarkdown, !subtitleMarkdown.isEmpty {
                    MarkdownRenderedText(
                        markdown: subtitleMarkdown,
                        lineLimit: 2,
                        font: .subheadline.weight(.semibold),
                        foregroundColor: .primary
                    )
                } else {
                    Text(subtitle)
                        .font(.subheadline.weight(.semibold))
                        .foregroundStyle(.primary)
                        .lineLimit(2)
                }

                if let accessory {
                    accessory()
                }

                Text(footer)
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
            .padding(14)
            .frame(width: 220, alignment: .leading)
            .background(Color(uiColor: .secondarySystemGroupedBackground), in: RoundedRectangle(cornerRadius: 20, style: .continuous))
            .overlay(
                RoundedRectangle(cornerRadius: 20, style: .continuous)
                    .stroke(Color.secondary.opacity(0.12))
            )
        }
        .buttonStyle(.plain)
    }
}

extension NodeHighlightTile where Accessory == EmptyView {
    init(
        title: String,
        systemImage: String,
        subtitle: String,
        subtitleMarkdown: String? = nil,
        footer: String,
        onTap: @escaping () -> Void
    ) {
        self.init(
            title: title,
            systemImage: systemImage,
            subtitle: subtitle,
            subtitleMarkdown: subtitleMarkdown,
            footer: footer,
            accessory: nil,
            onTap: onTap
        )
    }
}

struct NodeMiniThumbStrip: View {
    let attachments: [MetaAttachment]

    var body: some View {
        HStack(spacing: 6) {
            ForEach(attachments.prefix(3)) { att in
                NodeThumbMiniTile(attachment: att)
            }
        }
    }
}

private struct NodeThumbMiniTile: View {
    let attachment: MetaAttachment


    @Environment(\.displayScale) private var displayScale
    @State private var thumbnail: UIImage? = nil

    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 10, style: .continuous)
                .fill(.quaternary)

            if let thumbnail {
                Image(uiImage: thumbnail)
                    .resizable()
                    .scaledToFill()
                    .clipShape(RoundedRectangle(cornerRadius: 10, style: .continuous))
            } else {
                Image(systemName: "photo")
                    .font(.system(size: 12, weight: .semibold))
                    .foregroundStyle(.secondary)
            }
        }
        .frame(width: 34, height: 34)
        .clipped()
        .task(id: attachment.id) {
            await loadThumbnailIfNeeded()
        }
    }

    private func loadThumbnailIfNeeded() async {
        if thumbnail != nil { return }

        guard let url = await AttachmentHydrator.shared.ensureFileURL(
            attachmentID: attachment.id,
            fileExtension: attachment.fileExtension,
            localPath: attachment.localPath
        ) else {
            return
        }

        let scale = displayScale
        let requestSize = CGSize(width: 140, height: 140)

        let img = await AttachmentThumbnailStore.shared.thumbnail(
            attachmentID: attachment.id,
            fileURL: url,
            isVideo: false,
            requestSize: requestSize,
            scale: scale
        )

        await MainActor.run {
            thumbnail = img
        }
    }
}

struct NodeNotesCard: View {
    @Binding var notes: String
    let onEdit: () -> Void

    private var trimmed: String {
        notes.trimmingCharacters(in: .whitespacesAndNewlines)
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            NodeCardHeader(
                title: "Notiz",
                systemImage: "note.text",
                trailingTitle: "Bearbeiten",
                trailingSystemImage: "pencil",
                trailingAction: onEdit
            )

            if trimmed.isEmpty {
                NodeEmptyStateRow(
                    text: "Noch keine Notiz hinterlegt.",
                    ctaTitle: "Notiz schreiben",
                    ctaSystemImage: "pencil",
                    ctaAction: onEdit
                )
            } else {
                MarkdownRenderedText(markdown: trimmed, lineLimit: 6)
                    .frame(maxWidth: .infinity, alignment: .leading)
            }
        }
        .padding(16)
        .background(Color(uiColor: .secondarySystemGroupedBackground), in: RoundedRectangle(cornerRadius: 24, style: .continuous))
        .overlay(
            RoundedRectangle(cornerRadius: 24, style: .continuous)
                .stroke(Color.secondary.opacity(0.12))
        )
    }
}


struct MarkdownRenderedText: View {
    let markdown: String
    var lineLimit: Int? = nil
    var font: Font = .body
    var foregroundColor: Color = .primary

    private var renderedAttributedString: AttributedString? {
        Self.makeRenderedAttributedString(from: markdown)
    }

    var body: some View {
        Group {
            if let renderedAttributedString {
                Text(renderedAttributedString)
            } else {
                Text(MarkdownCommands.plainText(from: markdown))
            }
        }
        .font(font)
        .foregroundStyle(foregroundColor)
        .lineLimit(lineLimit)
        .multilineTextAlignment(.leading)
    }

    private static func makeRenderedAttributedString(from markdown: String) -> AttributedString? {
        let normalized = markdown
            .replacingOccurrences(of: "\r\n", with: "\n")
            .trimmingCharacters(in: .whitespacesAndNewlines)

        guard !normalized.isEmpty else { return nil }

        let lines = normalized.split(separator: "\n", omittingEmptySubsequences: false)
        var combined = AttributedString()
        var hasVisibleContent = false

        for index in lines.indices {
            if index > lines.startIndex {
                combined += AttributedString("\n")
            }

            let line = String(lines[index])
            guard !line.isEmpty else { continue }

            if let attributedLine = try? AttributedString(markdown: line) {
                combined += attributedLine
                hasVisibleContent = true
            } else {
                combined += AttributedString(MarkdownCommands.plainText(from: line))
                hasVisibleContent = true
            }
        }

        return hasVisibleContent ? combined : nil
    }
}

struct NodeOwnerCard: View {
    let owner: MetaEntity

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            NodeCardHeader(title: "Zugehörige Entität", systemImage: "cube")

            NavigationLink {
                EntityDetailView(entity: owner)
            } label: {
                HStack(spacing: 12) {
                    Image(systemName: owner.iconSymbolName ?? "cube")
                        .font(.system(size: 18, weight: .semibold))
                        .frame(width: 28)
                        .foregroundStyle(.tint)

                    VStack(alignment: .leading, spacing: 2) {
                        Text(owner.name.isEmpty ? "Entität" : owner.name)
                            .foregroundStyle(.primary)
                        Text("Öffnen")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }

                    Spacer(minLength: 0)
                    Image(systemName: "chevron.right")
                        .font(.footnote)
                        .foregroundStyle(.secondary)
                }
                .padding(12)
                .background(Color(uiColor: .tertiarySystemGroupedBackground), in: RoundedRectangle(cornerRadius: 16, style: .continuous))
            }
        }
        .padding(16)
        .background(Color(uiColor: .secondarySystemGroupedBackground), in: RoundedRectangle(cornerRadius: 24, style: .continuous))
        .overlay(
            RoundedRectangle(cornerRadius: 24, style: .continuous)
                .stroke(Color.secondary.opacity(0.12))
        )
    }
}

enum NodeTopLinks {
    static func compute(outgoing: [MetaLink], incoming: [MetaLink], max: Int) -> [NodeRef] {
        var refs: [NodeRef] = []

        for l in outgoing {
            refs.append(NodeRef(kind: l.targetKind, id: l.targetID, label: l.targetLabel, iconSymbolName: nil))
            if refs.count >= max { return refs }
        }

        for l in incoming {
            refs.append(NodeRef(kind: l.sourceKind, id: l.sourceID, label: l.sourceLabel, iconSymbolName: nil))
            if refs.count >= max { return refs }
        }

        return refs
    }

    static func previewText(_ s: String, maxChars: Int) -> String {
        let trimmed = s.trimmingCharacters(in: .whitespacesAndNewlines)
        if trimmed.count <= maxChars { return trimmed }
        let idx = trimmed.index(trimmed.startIndex, offsetBy: maxChars)
        return String(trimmed[..<idx]) + "…"
    }
}
