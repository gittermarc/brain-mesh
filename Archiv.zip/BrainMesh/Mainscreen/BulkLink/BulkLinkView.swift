//
//  BulkLinkView.swift
//  BrainMesh
//
//  Created by Marc Fechner on 12.02.26.
//

import SwiftUI
import SwiftData

struct BulkLinkView: View {
    @Environment(\.dismiss) private var dismiss
    @Environment(\.modelContext) private var modelContext

    let source: NodeRef
    let graphID: UUID?
    let onCompleted: ((BulkLinkCompletion) -> Void)?

    @State private var selectedTargets: Set<NodeRef> = []
    @State private var note: String = ""
    @State private var createBidirectional: Bool = false
    @State private var ignoreDuplicates: Bool = true

    @State private var existingOutgoingTargets: Set<NodeRefKey> = []
    @State private var existingIncomingSources: Set<NodeRefKey> = []

    @State private var showOnlyUnlinked: Bool = false
    @State private var resultAlert: BulkLinkResult?
    @State private var errorAlert: BulkLinkError?
    @State private var isSaving: Bool = false

    init(source: NodeRef, graphID: UUID?, onCompleted: ((BulkLinkCompletion) -> Void)? = nil) {
        self.source = source
        self.graphID = graphID
        self.onCompleted = onCompleted
    }

    private var loadKey: BulkLinkLoadKey {
        BulkLinkLoadKey(sourceID: source.id, graphID: graphID)
    }

    var body: some View {
        NavigationStack {
            Form {
                Section("Quelle") {
                    HStack(spacing: 12) {
                        Image(systemName: source.iconSymbolName ?? (source.kind == .entity ? "cube" : "tag"))
                            .font(.system(size: 16, weight: .semibold))
                            .frame(width: 22)
                            .foregroundStyle(.tint)
                        Text(source.label)
                    }
                }

                Section("Ziele") {
                    NavigationLink {
                        NodeMultiPickerView(
                            source: source,
                            graphID: graphID,
                            selection: $selectedTargets,
                            alreadyLinkedTargets: existingOutgoingTargets,
                            showOnlyUnlinked: $showOnlyUnlinked
                        )
                    } label: {
                        HStack {
                            Text("Ziele auswählen")
                            Spacer()
                            Text("\(selectedTargets.count)")
                                .foregroundStyle(.secondary)
                        }
                    }

                    if !selectedTargets.isEmpty {
                        let preview = selectedPreviewRows
                        ForEach(preview, id: \.self) { row in
                            HStack(spacing: 12) {
                                Image(systemName: row.iconSymbolName ?? (row.kind == .entity ? "cube" : "tag"))
                                    .font(.system(size: 14, weight: .semibold))
                                    .frame(width: 22)
                                    .foregroundStyle(.tint)
                                Text(row.label)
                                Spacer(minLength: 0)
                                Button {
                                    selectedTargets.remove(row)
                                } label: {
                                    Image(systemName: "xmark.circle.fill")
                                        .foregroundStyle(.secondary)
                                }
                                .buttonStyle(.plain)
                                .accessibilityLabel("Entfernen")
                            }
                        }

                        if selectedTargets.count > preview.count {
                            Text("… und \(selectedTargets.count - preview.count) weitere")
                                .font(.caption)
                                .foregroundStyle(.secondary)
                        }
                    }
                }

                Section("Optionen") {
                    Toggle("Bidirektional", isOn: $createBidirectional)
                    Toggle("Doppelte ignorieren", isOn: $ignoreDuplicates)
                }

                Section("Notiz (optional)") {
                    TextField("z.B. Kontext", text: $note, axis: .vertical)
                }
            }
            .navigationTitle("Mehrere Links")
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Abbrechen") { dismiss() }
                }
            }
            .safeAreaInset(edge: .bottom) {
                VStack(spacing: 10) {
                    Button {
                        Task { @MainActor in
                            await save()
                        }
                    } label: {
                        HStack(spacing: 10) {
                            if isSaving {
                                ProgressView()
                                    .controlSize(.small)
                            }
                            Text(isSaving ? "Erstelle…" : saveButtonTitle)
                        }
                        .frame(maxWidth: .infinity)
                    }
                    .buttonStyle(.borderedProminent)
                    .disabled(selectedTargets.isEmpty || isSaving)
                }
                .padding(.horizontal)
                .padding(.vertical, 8)
                .background(.ultraThinMaterial)
            }
            .task(id: loadKey) {
                await refreshExistingLinkSets()
            }
            .alert(item: $resultAlert) { result in
                Alert(
                    title: Text("Links erstellt"),
                    message: Text(result.message),
                    dismissButton: .default(Text("OK")) {
                        dismiss()
                    }
                )
            }
            .alert(item: $errorAlert) { error in
                Alert(
                    title: Text("Nicht möglich"),
                    message: Text(error.message),
                    dismissButton: .default(Text("OK"))
                )
            }
        }
    }

    private var saveButtonTitle: String {
        let count = selectedTargets.count
        if count == 0 { return "Erstelle Links" }
        return "Erstelle \(count) Link\(count == 1 ? "" : "s")"
    }

    private var selectedPreviewRows: [NodeRef] {
        Array(selectedTargets)
            .sorted(by: { BMSearch.fold($0.label) < BMSearch.fold($1.label) })
            .prefix(5)
            .map { $0 }
    }

    @MainActor
    private func refreshExistingLinkSets() async {
        await BulkLinkLoader.shared.configure(container: AnyModelContainer(modelContext.container))

        do {
            let snapshot = try await BulkLinkLoader.shared.loadSnapshot(
                sourceKindRaw: source.kind.rawValue,
                sourceID: source.id,
                graphID: graphID
            )

            existingOutgoingTargets = snapshot.existingOutgoingTargets
            existingIncomingSources = snapshot.existingIncomingSources
        } catch {
            existingOutgoingTargets = []
            existingIncomingSources = []
        }
    }

    @MainActor
    private func save() async {
        if isSaving { return }
        isSaving = true
        defer { isSaving = false }

        await refreshExistingLinkSets()

        let plan: BulkLinkMutationPlan
        do {
            plan = try BulkLinkPlanner.makePlan(
                source: source,
                selectedTargets: selectedTargets,
                note: note,
                createBidirectional: createBidirectional,
                ignoreDuplicates: ignoreDuplicates,
                existingOutgoingTargets: existingOutgoingTargets,
                existingIncomingSources: existingIncomingSources,
                graphID: graphID
            )
        } catch let plannerError as BulkLinkPlannerError {
            errorAlert = BulkLinkError(message: plannerError.message)
            return
        } catch {
            errorAlert = BulkLinkError(message: "Nicht möglich: \(error.localizedDescription)")
            return
        }

        let completion: BulkLinkCompletion
        do {
            completion = try BulkLinkExecutor.execute(
                plan: plan,
                insert: { draft in
                    let link = MetaLink(
                        sourceKind: draft.source.kind,
                        sourceID: draft.source.id,
                        sourceLabel: draft.source.label,
                        targetKind: draft.target.kind,
                        targetID: draft.target.id,
                        targetLabel: draft.target.label,
                        note: draft.note,
                        graphID: draft.graphID
                    )
                    modelContext.insert(link)
                    return link
                },
                save: {
                    try modelContext.save()
                },
                rollback: { inserted in
                    for link in inserted {
                        modelContext.delete(link)
                    }
                }
            )
        } catch {
            errorAlert = BulkLinkError(message: "Speichern fehlgeschlagen: \(error.localizedDescription)")
            await refreshExistingLinkSets()
            return
        }

        if let onCompleted {
            onCompleted(completion)
            return
        }

        if completion.totalCreated == 0 {
            resultAlert = BulkLinkResult(
                message: "Keine neuen Links erstellt.\n\nÜbersprungen: \(completion.skippedDuplicates) doppelt, \(completion.skippedSelf) self-link."
            )
            return
        }

        var parts: [String] = []
        parts.append("Erstellt: \(completion.createdForward) ausgehend")
        if completion.isBidirectional {
            parts.append("\(completion.createdReverse) rückwärts")
        }
        if completion.skippedDuplicates > 0 {
            parts.append("Übersprungen: \(completion.skippedDuplicates) doppelt")
        }
        if completion.skippedSelf > 0 {
            parts.append("Übersprungen: \(completion.skippedSelf) self-link")
        }
        resultAlert = BulkLinkResult(message: parts.joined(separator: "\n"))
    }
}

private struct BulkLinkLoadKey: Hashable {
    let sourceID: UUID
    let graphID: UUID?
}

private struct BulkLinkResult: Identifiable {
    let id: UUID = UUID()
    let message: String
}

private struct BulkLinkError: Identifiable {
    let id: UUID = UUID()
    let message: String
}
