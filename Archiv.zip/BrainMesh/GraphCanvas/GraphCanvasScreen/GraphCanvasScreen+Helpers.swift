//
//  GraphCanvasScreen+Helpers.swift
//  BrainMesh
//

import SwiftUI
import SwiftData
import Foundation

extension GraphCanvasScreen {

    // MARK: - Spotlight edges (Nodes-only default + Degree cap)

    func edgesForDisplay() -> [GraphEdge] {
        GraphCanvasDisplayEdgesPlanner.displayEdges(
            selection: selection,
            allEdges: edges,
            showAllLinksForSelection: showAllLinksForSelection,
            degreeCap: degreeCap,
            labelForKey: { key in
                displayLabel(for: key)
            }
        )
    }

    func displayLabel(for key: NodeKey) -> String {
        if let cached = labelCache[key] { return cached }
        return nodes.first(where: { $0.key == key })?.label ?? ""
    }

    func hiddenLinkCountForSelection() -> Int {
        GraphCanvasDisplayEdgesPlanner.hiddenLinkCount(
            selection: selection,
            allEdges: edges,
            showAllLinksForSelection: showAllLinksForSelection,
            degreeCap: degreeCap
        )
    }


    // MARK: - Helpers

    func nodeForKey(_ key: NodeKey) -> GraphNode? {
        nodes.first(where: { $0.key == key })
    }

    func fetchEntity(id: UUID) -> MetaEntity? {
        let nodeID = id
        let fd = FetchDescriptor<MetaEntity>(predicate: #Predicate { e in e.id == nodeID })
        guard let e = try? modelContext.fetch(fd).first else { return nil }
        if let gid = activeGraphID {
            return (e.graphID == gid || e.graphID == nil) ? e : nil
        }
        return e
    }

    func fetchAttribute(id: UUID) -> MetaAttribute? {
        let nodeID = id
        let fd = FetchDescriptor<MetaAttribute>(predicate: #Predicate { a in a.id == nodeID })
        guard let a = try? modelContext.fetch(fd).first else { return nil }
        if let gid = activeGraphID {
            return (a.graphID == gid || a.graphID == nil) ? a : nil
        }
        return a
    }

    func selectedImagePath() -> String? {
        guard let sel = selection else { return nil }
        return imagePathCache[sel]
    }

    @MainActor
    func recomputeDetailsFocusPreparedState() {
        let visibleAttributeIDs = nodes.compactMap { node in
            node.key.kind == .attribute ? node.key.uuid : nil
        }

        guard !visibleAttributeIDs.isEmpty else {
            detailsFocusPreparedState = .empty
            return
        }

        let attributeIDs = Array(Set(visibleAttributeIDs))
        let attributeDescriptor = FetchDescriptor<MetaAttribute>(
            predicate: #Predicate<MetaAttribute> { attribute in
                attributeIDs.contains(attribute.id)
            }
        )
        let attributes = (try? modelContext.fetch(attributeDescriptor)) ?? []

        let entityIDs = Array(Set(attributes.compactMap { $0.owner?.id }))
        let entities: [MetaEntity]
        if entityIDs.isEmpty {
            entities = []
        } else {
            let entityDescriptor = FetchDescriptor<MetaEntity>(
                predicate: #Predicate<MetaEntity> { entity in
                    entityIDs.contains(entity.id)
                }
            )
            entities = (try? modelContext.fetch(entityDescriptor)) ?? []
        }

        detailsFocusPreparedState = GraphDetailsPreparedState.build(
            entities: entities,
            attributes: attributes
        )
    }

    @MainActor
    func handleSelectionChange(_ newSelection: NodeKey?) {
        showAllLinksForSelection = false

        if let key = newSelection {
            Task {
                await ensureLocalMainImageCacheForSelectionIfNeeded(key)
            }
        }

        recomputeDetailsPeek(for: newSelection)
        recomputeDerivedState()
    }


    // MARK: - On-demand image hydration (Fix A)

    /// Ensures that the selected node's main image is available as a local cached JPEG file.
    ///
    /// Why: The graph overlay loads thumbnails from the local file cache for performance.
    /// If a record was synced to this device, `imagePath` may exist while the local file does not yet.
    /// This method writes the deterministic file on-demand (only for the current selection) and updates the render cache.
    @MainActor
    func ensureLocalMainImageCacheForSelectionIfNeeded(_ key: NodeKey) async {
        switch key.kind {
        case .entity:
            guard let e = fetchEntity(id: key.uuid) else { return }
            guard let d = e.imageData, !d.isEmpty else { return }

            let expected = "\(e.id.uuidString).jpg"
            let currentPath = (e.imagePath?.isEmpty == false) ? e.imagePath! : expected
            let hasFile = ImageStore.fileExists(path: currentPath)

            // Force a `selectedImagePath` change (nil -> filename) so GraphCanvasView refreshes its thumbnail cache.
            if !hasFile, selection == key {
                imagePathCache.removeValue(forKey: key)
            }

            guard let ensured = await ImageHydrator.ensureCachedJPEGExists(stableID: e.id, jpegData: d) else { return }

            var didModelChange = false
            if e.imagePath != ensured {
                e.imagePath = ensured
                didModelChange = true
            }
            if didModelChange { try? modelContext.save() }

            imagePathCache[key] = ensured

        case .attribute:
            guard let a = fetchAttribute(id: key.uuid) else { return }
            guard let d = a.imageData, !d.isEmpty else { return }

            let expected = "\(a.id.uuidString).jpg"
            let currentPath = (a.imagePath?.isEmpty == false) ? a.imagePath! : expected
            let hasFile = ImageStore.fileExists(path: currentPath)

            if !hasFile, selection == key {
                imagePathCache.removeValue(forKey: key)
            }

            guard let ensured = await ImageHydrator.ensureCachedJPEGExists(stableID: a.id, jpegData: d) else { return }

            var didModelChange = false
            if a.imagePath != ensured {
                a.imagePath = ensured
                didModelChange = true
            }
            if didModelChange { try? modelContext.save() }

            imagePathCache[key] = ensured
        }
    }

    // MARK: - Cache refresh (after editing in detail sheets)

    @MainActor
    func refreshNodeCaches(for key: NodeKey) {
        switch key.kind {
        case .entity:
            guard let e = fetchEntity(id: key.uuid) else { return }

            if let idx = nodes.firstIndex(where: { $0.key == key }) {
                nodes[idx] = GraphNode(key: key, label: e.name)
            }

            labelCache[key] = e.name
            if let p = e.imagePath, !p.isEmpty { imagePathCache[key] = p }
            else { imagePathCache.removeValue(forKey: key) }

            if let s = e.iconSymbolName, !s.isEmpty { iconSymbolCache[key] = s }
            else { iconSymbolCache.removeValue(forKey: key) }

        case .attribute:
            guard let a = fetchAttribute(id: key.uuid) else { return }

            if let idx = nodes.firstIndex(where: { $0.key == key }) {
                nodes[idx] = GraphNode(key: key, label: a.name)
            }

            // DisplayName ist fürs Sorting/Chip besser als nur der Attributname
            labelCache[key] = a.displayName
            if let p = a.imagePath, !p.isEmpty { imagePathCache[key] = p }
            else { imagePathCache.removeValue(forKey: key) }

            if let s = a.iconSymbolName, !s.isEmpty { iconSymbolCache[key] = s }
            else { iconSymbolCache.removeValue(forKey: key) }
        }
    }

    // MARK: - Graph Jump staging (PR 3)

    /// Stages a pending jump so it can be applied after the next load (when nodes + layout are available).
    @MainActor
    func stageGraphJump(_ jump: GraphJump) {
        // Avoid re-staging the same jump repeatedly.
        if stagedJumpID == jump.id { return }
        stagedJumpID = jump.id
        stagedJumpGraphID = jump.graphID
        stagedSelectAfterLoad = jump.nodeKey
        stagedCenterAfterLoad = jump.centerOnArrival ? jump.nodeKey : nil
    }

    @MainActor
    func clearStagedGraphJump() {
        stagedJumpID = nil
        stagedJumpGraphID = nil
        stagedSelectAfterLoad = nil
        stagedCenterAfterLoad = nil
    }

    /// Applies the staged jump if the required node exists in the just-loaded snapshot.
    @MainActor
    func applyStagedJumpAfterLoadIfNeeded(availableKeys: Set<NodeKey>) {
        guard let stagedID = stagedJumpID else { return }
        guard let stagedGraphID = stagedJumpGraphID else { return }
        guard let key = stagedSelectAfterLoad else { return }

        // Only apply if this load belongs to the expected graph.
        guard activeGraphID == stagedGraphID else { return }
        guard availableKeys.contains(key) else { return }

        selection = key

        if stagedCenterAfterLoad == key {
            centerOnNodeAfterLayout(key)
        }

        // Consume only if the coordinator still holds the same jump.
        if let pending = graphJump.pendingJump, pending.id == stagedID {
            _ = graphJump.consumeJump()
        }

        clearStagedGraphJump()
    }

    /// Centers the camera after SwiftUI had a chance to commit `positions` for the new layout.
    @MainActor
    func centerOnNodeAfterLayout(_ key: NodeKey) {
        Task { @MainActor in
            await Task.yield()
            guard positions[key] != nil else { return }
            cameraCommand = CameraCommand(kind: .center(key))
        }
    }


}
