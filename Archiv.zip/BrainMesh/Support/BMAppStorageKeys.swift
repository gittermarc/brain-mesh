//
//  BMAppStorageKeys.swift
//  BrainMesh
//
//  Centralized UserDefaults/@AppStorage keys.
//  Added in PR 01 to reduce stringly-typed keys spread across the codebase.
//

enum BMAppStorageKeys {

    // MARK: - Global graph/session

    static let activeGraphID = "BMActiveGraphID"

    // MARK: - Onboarding

    static let onboardingHidden = "BMOnboardingHidden"
    static let onboardingCompleted = "BMOnboardingCompleted"
    static let onboardingAutoShown = "BMOnboardingAutoShown"

    // MARK: - Hydrators

    static let imageHydratorLastAutoRun = "BMImageHydratorLastAutoRun"

    // MARK: - Entities / attributes

    static let entitiesHomeSort = "BMEntitiesHomeSort"
    static let entityAttributeSortMode = "BMEntityAttributeSortMode"

    static let entityAttributesAllSort = "BMEntityAttributesAllSort"
    static let entityAttributesAllShowPinnedDetails = "BMEntityAttributesAllShowPinnedDetails"
    static let entityAttributesAllShowNotesPreview = "BMEntityAttributesAllShowNotesPreview"

    // MARK: - Icons

    static let recentSymbolNames = "BMRecentSymbolNames"

    // MARK: - Local recents

    static let recentNodesV1 = "BMRecentNodesV1"
    static let graphCanvasFocusHistoryV1 = "BMGraphCanvasFocusHistoryV1"
    static let graphCanvasViewPresetsV1 = "BMGraphCanvasViewPresetsV1"

    // MARK: - Appearance

    static let appearanceSettingsV1 = "BMAppearanceSettingsV1"

    // MARK: - Display

    static let displaySettingsV1 = "BMDisplaySettingsV1"

    /// One-time migration flag: legacy All-Attributes AppStorage → DisplaySettingsStore.
    static let displaySettingsMigratedAttributesAllV1 = "BMDisplaySettingsMigratedAttributesAllV1"

    /// One-time migration flag: legacy EntitiesHome Appearance → DisplaySettingsStore.
    static let displaySettingsMigratedEntitiesHomeFromAppearanceV1 = "BMDisplaySettingsMigratedEntitiesHomeFromAppearanceV1"

    // MARK: - Video import

    static let compressVideosOnImport = "BMCompressVideosOnImport"
    static let videoCompressionQuality = "BMVideoCompressionQuality"

    // MARK: - Image import (gallery)

    static let galleryImageCompressionPreset = "BMGalleryImageCompressionPreset"
}
